function redirectYouTubeLinks() {
    var youtubeLinks = document.querySelectorAll('a[href*="youtube.com/watch?v="]');
    youtubeLinks.forEach(function(link) {
        var videoId = link.href.split('v=')[1];
        if (videoId) {
            var embedUrl = 'https://www.youtube-nocookie.com/embed/' + videoId;
            link.href = embedUrl;
        }
    });
}

redirectYouTubeLinks();

